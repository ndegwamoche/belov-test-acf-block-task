<?php

/**
 * Footer
 * 
 * @link https://github.com/ndegwamoche/belov-test
 *
 * @package belov-test
 */
?>

<?php wp_footer(); ?>

</body>

</html>